define(function(require, exports, module) {
	var FW = require("../breeze/framework/js/BreezeFW");
	FW.register(
		{
			name:"graph",			
			param:{
				
			},
			onCreate:function(){
				
			},
			public:{
				drawLine:function(srcDom,destDom,text,type){
					
				}
			}
		}
	);
	return FW;
});